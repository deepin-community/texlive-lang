---
myst:
  html_meta:
    keywords: LaTeX, généralités, bases
---

# Bases

Cette section regroupe quelques questions souvent posées par des
personnes qui débutent avec TeX et LaTeX. Trois questions peuvent vous
intéresser avant même d'aborder les points listés ici :

-   [](/1_generalites/bases/comment_faire_ses_premiers_pas)
-   [](/1_generalites/glossaire/tex)
-   [](/1_generalites/glossaire/latex)


## Les caractéristiques de TeX

-   [](/1_generalites/bases/principes_de_base_de_tex)
-   [](/1_generalites/bases/ecrire_en_tex)
-   [](/1_generalites/bases/pourquoi_est_ce_gratuit)
-   [](/1_generalites/bases/wysiwyg)
-   [](/1_generalites/bases/verifier_la_conformite_de_son_compilateur)
-   [](/1_generalites/bases/comment_prononcer_tex)


## TeX et LaTeX

-   [](/1_generalites/bases/differences_entre_latex_et_tex)
-   [](/1_generalites/bases/principes_de_base_de_latex)
-   [](/1_generalites/bases/dois_je_utiliser_tex_ou_latex)


## ConTeXt

-   [](/1_generalites/glossaire/context)
-   [](/1_generalites/bases/debuter_avec_context)


## Les logiciels autour de TeX et LaTeX

-   [](/1_generalites/bases/comment_lire_un_fichier_latex)
-   [](/1_generalites/glossaire/distribution)
-   [](/1_generalites/bases/wysiwyg2)
-   [](/1_generalites/bases/distinguer_tex_et_ses_amis)


## Et pour quelques dollars de plus...

-   [](/1_generalites/bases/peut_on_devenir_riche_avec_latex)
-   [](/1_generalites/bases/etre_prestataire_de_services_latex)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```