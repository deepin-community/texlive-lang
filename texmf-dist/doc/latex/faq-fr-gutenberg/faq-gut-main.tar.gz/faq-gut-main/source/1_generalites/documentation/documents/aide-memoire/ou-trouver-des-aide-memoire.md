---
myst:
  html_meta:
    keywords: LaTeX,documentation
---
# Où trouver des aide-mémoire ?

## En français

- Philippe Goutet, [Aide-mémoire LaTeX](http://pgoutet.free.fr/latex/aide-memoire.pdf). Ce document accompagne un cours donné par l'auteur.
- Christophe Aubry, *LaTeX : conception de documents élaborés et structurés*,
  ENI, 2021, ISBN 978-2-409-03081-9, 12 pages, 7 euros. Voir [l'article](https://doi.org/10.60028/lettre.vi44.24)
  que *La Lettre GUTenberg* a consacré à cet aide-mémoire.

## En anglais

- Winston Chang, [LaTeXe Cheat Sheet](ctanpkg:latexcheat). Il s'agit d'une liste d'éléments à retenir pour utiliser LaTeX. Le tout tient sur une feuille recto-verso.
