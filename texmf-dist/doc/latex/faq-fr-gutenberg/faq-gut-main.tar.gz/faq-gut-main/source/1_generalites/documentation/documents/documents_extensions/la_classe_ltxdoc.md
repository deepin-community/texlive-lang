---
myst:
  html_meta:
    keywords: LaTeX, généralités, documentation, documents, programmation, 
              literate programming, packages, extensions
---

# À quoi sert la classe <ctanpkg:ltxdoc> ?

La classe <ctanpkg:ltxdoc> est un peu particulière : 
elle sert à produire de la documentation pour les extensions ou les classes. 
L'extension ou la classe sont alors fournies sous forme d'un "kit d'installation", 
contenant un fichier `.ins` et un fichier `.dtx` ou `.doc`. 
Le premier contient les sources des fichiers nécessaires ainsi que la documentation 
(on parle de [Literate Programming](/5_fichiers/formats/web/literate_programming)). 
Ces fichiers pourront être extraits en compilant le second fichier dit "d'installation".

La [documentation](texdoc:ltxdoc) de la classe <ctanpkg:ltxdoc> est disponible 
dans toutes les distributions. 
Le [LaTeX Companion](https://www.latex-project.org/help/books/#french) 
contient également une section à propos de la classe <ctanpkg:ltxdoc>.

Il faut noter que plusieurs classes ont été développées récemment pour remplacer `ltxdoc` 
en y ajoutant des fonctionnalités. Notamment :
- <ctanpkg:skdoc> de Simon Sigurdhsson, [activement développée](https://github.com/urdh/skdoc) ;
- <ctanpkg:ydoc> de Martin Scharrer, qui est en version alpha 
  et dont le développement semble s'être arrêté en 2011.

:::{sources}
[Classes for LaTeX documentation](https://tex.stackexchange.com/q/45421), 
sur [Tex Stack Exchange](https://tex.stackexchange.com/)
:::