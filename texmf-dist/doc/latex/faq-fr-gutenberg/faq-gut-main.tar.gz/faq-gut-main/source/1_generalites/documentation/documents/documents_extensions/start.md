---
myst:
  html_meta:
    keywords: LaTeX,documentation,documentation d'extension,documents en ligne,manuel d'un package
---

# Documentation des extensions


Cette section traite de la documentation des différentes extensions de
TeX, LaTeX et des logiciels associés.

## Généralités

-   [Où trouver la documentation des extensions ?](/1_generalites/documentation/documents/documents_extensions/documentation_des_packages)
-   [Comment générer la documentation d'une extension ?](/1_generalites/documentation/documents/documents_extensions/documentation_des_packages3)
-   [Que sont les fichiers de source documentée (ou fichiers « dtx ») ?](/1_generalites/documentation/documents/documents_extensions/fichiers_sources_dtx)
-   [À quoi sert la classe "ltxdoc" ?](/1_generalites/documentation/documents/documents_extensions/la_classe_ltxdoc)

## Cas particuliers

-   [Où trouver la documentation française de KOMA-Script ?](/1_generalites/documentation/documents/documents_extensions/koma-script_en_francais)
-   [Où trouver le manuel PicTeX ?](/1_generalites/documentation/documents/documents_extensions/manuel_de_pictex)

```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
