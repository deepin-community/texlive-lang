---
myst:
  html_meta:
    keywords: LaTeX,LaTeX 2.09
---
# Que lire sur LaTeX 2.09 ?

:::{warning}
[LaTeX 2.09](ctanpkg:latex209) est obsolète, sa dernière version ayant été mise
à disposition en 1993. Son utilisation n'est donc pas recommandée.
:::

- Chantal Simian, [LaTeX - Manuel utilisateur simplifié](https://mirror.gutenberg-asso.fr/tex.loria.fr/general/latex-intro.ps.gz), 1992.
