---
myst:
  html_meta:
    keywords: livres,documentation,LaTeX
---
# Que lire sur LaTeXe ?

## En français

- Marc Baudoin, [Apprends LaTeX !](http://www.babafou.eu.org/Apprends_LaTeX/Apprends_LaTeX.pdf) (2012). Il s'agit du manuel de formation de l'ENSTA, également disponible sur le [site du CTAN](ctanpkg:apprends-latex).
- Benjamin Bayart, [Joli manuel pour LaTeXe](https://mirror.gutenberg-asso.fr/tex.loria.fr/general/manuel2ep.pdf).
- Adrien Bouzigues, [Initiation à LaTeX - Pour débutants ou jeunes utilisateurs](ctanpkg:guide-latex-fr).
- Fabien Conus et Franck Pastor, [Introduction à LaTeX sous macOS X](http://redac.cuk.ch/franck/article-cuk-latex-pdf/intro-latex-rev.pdf) (2009).
- Michel Goossens, [LateX2e, un aperçu](http://www.numdam.org/item/CG_1994___18_1_0.pdf) (tiré du [Cahier GUTenberg n°18](http://www.numdam.org/issues/CG_1994___18/)).
- Vincent Lozano, [Tout ce que vous avez toujours voulu savoir sur LaTeX sans jamais oser le demander](https://archives.framabook.org/tout-sur-latex/index.html). Il s'agit ici d'un livre libre, ce principe étant détaillé sur le site de [Framabook](https://deslivresencommuns.org/page/archives_framabook/).
- Tobias Oetiker, [Une courte (?) introduction à LaTeXe](ctanpkg:lshort-french) (2011).
- Florent Rougon, [Présentation rapide de LaTeX2e](http://frougon.net/writings/presentation_LaTeX/).
- Maïeul Rouquette, *(Xe)LaTeX appliqué aux sciences
humaines*, <ctanpkg:latex-sciences-humaines>, 2013. Ce livre propose une très bonne
introduction à LaTeX.
- Vincent Seguin, [Aide-mémoire LaTeX](https://mirror.gutenberg-asso.fr/tex.loria.fr/general/aide-memoire-latex-seguin1998.pdf) (2000).

## En anglais

- LaTeX3 Project Team, [LaTeXe for authors](ctanpkg:usrguide). Ce document décrit les changements entre LaTeX 2.09 et LaTeX.
- LaTeX3 Project Team, [The LaTeXe sources](ctanpkg:latex2e-help-texinfo). Ce document commente les fichiers source de LaTeX.
- Jon Warbrick *et al.*, [Essential LaTeX ++](https://www.researchgate.net/publication/2319358_Essential_LATEX). Ce document très pédagogique permet de réaliser un document LaTeX en quelques minutes.
