---
myst:
  html_meta:
    keywords: LaTeX,documentation,Postscript,polices de caractères
---
# Que lire sur les fontes ?

## En français

:::{todo} Ajouter d'autres références sur les fontes en français.
:::
- Daniel Flipo, *De pdfLaTeX
  à LuaLaTeX*, 2023. <http://daniel.flipo.free.fr/doc/luatex/pdf2lua.pdf>. Un
  excellent tutoriel pour une gestion évoluée des fontes, se concluant par un
  catalogue illustré des fontes courantes.
- Jacques André & Patrick Bideault, *La Fonte de ce numéro : Infini*. *La Lettre
  GUTenberg*, numéro 45 (mai 2022), pages
  42–80. <https://doi.org/10.60028/lettre.vi45.8>. Un étude fouillée de
  l'utilisation avec luaLaTeX de la fonte Infini, de Sandrine Nugue. Ce travail
  est évidemment utilisable avec d'autres fontes non *packagées* pour LaTeX.

## En anglais

- Il existe une FAQ `comp.fonts` disponible sur <https://nwalsh.com/comp.fonts/FAQ/index.html>
- La note sur les fontes Postscript [dans la documentation](texdoc:psnfss) de l'extension [PSNFSS](ctanpkg:psnfss).
