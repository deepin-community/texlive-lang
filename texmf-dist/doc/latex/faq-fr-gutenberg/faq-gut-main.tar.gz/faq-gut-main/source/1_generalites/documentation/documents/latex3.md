---
myst:
  html_meta:
    keywords: LaTeX,latex3,programming
---
# Que lire sur la programmation en LaTeX3 ?

Pour le moment, il n'y a pas de livre sur ce sujet. Toutefois, il existe quelques ressources pour le moment en anglais :

- la [documentation](texdoc:expl3) de l'extension <ctanpkg:expl3> donne un aperçu général des concepts ;
- la [documentation des interfaces](texdoc:interface3), fournie avec <ctanpkg:l3kernel>, présente une description complète des commandes ;
- le [site](https://www.latex-project.org/) du [projet LaTeX](/1_generalites/histoire/c_est_quoi_latex3) propose une liste de [publications](https://www.latex-project.org/publications/) ;
- Joseph Wright a écrit une courte série d'articles dans son [blog](https://www.texdev.net/) qui peut aider.

Enfin, nous vous recommandons la lecture de [cet article](/2_programmation/macros/comment_passer_a_la_definition_des_commandes_LaTeX3) de la présente FAQ, qui
traite de la définition des commandes en LaTeX3.

Le projet se poursuivant toujours, les documents continuent à évoluer. Certains des problèmes de conception plus larges sont discutés (toujours en anglais) sur la liste de diffusion LaTeX `latex-l`. Vous pouvez vous y abonner à cette liste en envoyant un message « `subscribe latex-l ⟨votre nom⟩` » à [listserv@urz.Uni-Heidelberg.de](mailto:listserv@urz.Uni-Heidelberg.de).

:::{sources}
[LaTeX3 programming](faquk:FAQ-latex3-prog)
:::
