---
myst:
  html_meta:
    keywords: LaTeX, généralités, documentation, listes de discussion, groupes de discussion,
              TUG, groupes d'utilisateurs.
---

# Listes et groupes de discussion


Cette section traite des associations, listes de discussion (et de diffusion) et
groupes de discussion sur les sujets de TeX, LaTeX et des autres
logiciels associés.
-   [](/1_generalites/documentation/listes_de_discussion/groupes_d_utilisateurs)
-   [](/1_generalites/documentation/listes_de_discussion/listes_de_discussion_francophones)
-   [](/1_generalites/documentation/listes_de_discussion/groupes_de_discussion)

En complément, avant de vous adresser à ces listes et groupes, pensez à
lire la question "[](/1_generalites/documentation/comment_obtenir_de_l_aide_en_ligne)". Cette section
présente d'ailleurs quelques conseils pour obtenir plus facilement de
l'aide lors d'échanges sur ces listes et groupes :

-   [](/1_generalites/documentation/listes_de_discussion/comment_poser_une_question)
-   [](/1_generalites/documentation/listes_de_discussion/comment_rediger_un_exemple_complet_minimal)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```