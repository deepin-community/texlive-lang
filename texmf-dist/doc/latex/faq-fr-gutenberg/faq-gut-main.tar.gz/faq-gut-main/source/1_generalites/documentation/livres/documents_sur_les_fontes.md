---
myst:
  html_meta:
    keywords: LaTeX
---
# Que lire sur les fontes et METAFONT ?

## En français

- Bernard Desgraupes, *METAFONT -- Guide pratique*, Vuibert, 2017, ISBN-10 2-7117-8642-0, ISBN-13 : 978-2-7117-8642-8.
- Yannis Haralambous, *Fontes et Codages*, O'Reilly, 2004, ISBN-10 2-8417-7273-X, ISBN-13 : 978-2-8417-7273-5.
- Daniel Flipo, *De pdfLaTeX
  à LuaLaTeX*, 2023. <http://daniel.flipo.free.fr/doc/luatex/pdf2lua.pdf>. Un
  excellent tutoriel pour une gestion évoluée des fontes, se concluant par un
  catalogue illustré des fontes courantes.
- Jacques André & Patrick Bideault, *La Fonte de ce numéro : Infini*. *La Lettre
  GUTenberg*, numéro 45 (mai 2022), pages
  42–80. <https://doi.org/10.60028/lettre.vi45.8>. Un étude fouillée de
  l'utilisation avec luaLaTeX de la fonte Infini, de Sandrine Nugue. Ce travail
  est évidemment utilisable avec d'autres fontes non *packagées* pour LaTeX.

## En anglais

- Alan Hoenig, *TeX Unbound : LaTeX and TeX strategies for fonts, graphics, and more*, Oxford University Press, 1998, ISBN-10 0-1950-9686-X, ISBN-13 978-0-1950-9686-6.
- Donald E. Knuth, *The METAFONTbook*, Addison Wesley, 1986, ISBN-10 0-2011-3444-6, ISBN-13 978-0-2011-3444-5.
