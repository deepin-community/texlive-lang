---
myst:
  html_meta:
    keywords: LaTeX, généralités, documentation, livres, bibliographie
---

# Livres


Cette section traite des livres disponibles dans les librairies sur les
sujets de TeX, LaTeX et des autres logiciels associés. Ces livres sont
classés ici par grandes thématiques.

-   [Que lire sur TeX et Plain TeX ?](/1_generalites/documentation/livres/documents_sur_tex)
-   [Que lire sur LaTeX ?](/1_generalites/documentation/livres/documents_sur_latex)
-   [Que lire sur les fontes et METAFONT ?](/1_generalites/documentation/livres/documents_sur_les_fontes)
-   [Que lire sur la typographie ?](/1_generalites/documentation/livres/documents_sur_la_typographie)


------------------------------------------------------------------------

*Source:* [Books relevant to TeX and friends](faquk:FAQ-book-lists)
```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
