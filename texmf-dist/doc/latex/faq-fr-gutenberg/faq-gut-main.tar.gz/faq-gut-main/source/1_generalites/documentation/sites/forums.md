---
myst:
  html_meta:
    keywords: LaTeX,documentation,forums de discussion,forums d'aide,forum web,questions-réponses sur LaTeX
---
# Où trouver des forums sur (La)TeX ?

Quelle que soit la langue dans laquelle on va demander de l'aide, il importe de
rédiger correctement un [exemple complet
minimal](/1_generalites/documentation/listes_de_discussion/comment_rediger_un_exemple_complet_minimal) ».

## En français
- [TeXnique.fr](https://texnique.fr/osqa/questions/) est le forum francophone de
  référence. C'est un site de questions et réponses, propulsé par l'[association
  GUTenberg](https://www.gutenberg-asso.fr), tout comme la présente FAQ.
- [MathemaTeX](https://www.mathematex.fr/) se présente comme un *Forum
  francophone relatif aux mathématiques avec support MathJax, LaTeX et
  Asymptote*.
- [Developpez.com>LaTeX](https://www.developpez.net/forums/f149/autres-langages/autres-langages/latex/) :
  Le site *Developpez.net* regroupe une communauté de développeurs dans une
  grande diversité de langages de programmation... dont LaTeX.

## En anglais

- [TopAnswers TeX](https://topanswers.xyz/tex) : ce site fonctionne sur le
  principe des questions-réponses, mais en y associant une messagerie
  instantanée qui donne un côté beaucoup plus humain aux échanges. De plus, il
  est dépourvu de publicités commerciales.
- [LaTeX Community](https://latex.org/forum/) : ce forum offre une large variété
  de sujets regroupés par catégorie.
