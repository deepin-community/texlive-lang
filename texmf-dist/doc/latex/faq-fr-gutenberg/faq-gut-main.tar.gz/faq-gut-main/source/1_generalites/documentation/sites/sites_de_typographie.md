---
myst:
  html_meta:
    keywords: livres,documentation,site web,LaTeX,typographie
---
# Quels sites visiter sur la typographie ?

## En français

- [Deux ou trois choses en typographie ou autres](https://jacques-andre.fr/),
  par Jacques André, dont c'est le site personnel.
- Le [blog du web design](https://www.blogduwebdesign.com/pages/ressources-web/typographie/) propose une série d'articles sur le sujet de la typographie.
- [Typographie & Civilisation](https://www.typographie.org/) fournit des éléments
  historiques sur le sujet ; malheureusement, la navigation n'y est pas très intuitive.
- La [liste typographie](http://listetypo.free.fr/).
- Le [site de Jean Méron](https://www.jean-meron.fr/page32.html) propose une liste de références documentaires.

## En anglais

- Le [site officiel de Monotype](https://www.monotype.com/). Monotype est l'une des grandes fonderies.
- [Type arts](http://www.typearts.com/index.html). Il s'agit du site, sans doute un peu daté, de quelques passionnés.
