---
myst:
  html_meta:
    keywords: LaTeX, généralités, documentation, documents sur LaTeX, documentations en français,
              débuter avec LaTeX, documents francophones, manuels en français
---

# Documentation

La documentation traitant de TeX et LaTeX est très développée, presque
exubérante. Pour faire un premier tri, les documents ont été classés par
type, en présentant si possibles des ressources en français et en
anglais :

-   les [documents en ligne](/1_generalites/documentation/documents/start) (ce qui inclut
    la [documentation des extensions](/1_generalites/documentation/documents/documents_extensions/start),
    les [introductions](/1_generalites/documentation/documents/tutoriels/start),
    les [tutoriels](/1_generalites/documentation/documents/tutoriels/start),
    les [aide-mémoire et dictionnaires de commandes](/1_generalites/documentation/documents/aide-memoire/start)) ;
-   les [livres](/1_generalites/documentation/livres/start) ;
-   les [listes et groupes de discussion](/1_generalites/documentation/listes_de_discussion/start) ;
-   les [sites web](/1_generalites/documentation/sites/start).

Si vous cherchez plus particulièrement de l'aide en ligne, il pourra
vous être utile de lire les deux questions suivantes :

-   [](/1_generalites/documentation/le_catalogue_du_ctan)
-   [](/1_generalites/documentation/comment_obtenir_de_l_aide_en_ligne)

[L'annuaire Dmoz](https://curlie.org/fr/Informatique/Logiciels/Composition/TeX/)
vous proposera sans doute des pointeurs complémentaires, en français et
en d'autres langues.

Si vous recherchez de l'actualité sur la communauté francophone, le
[site web de l'association GUTenberg](https://www.gutenberg-asso.fr/)
pourra sans doute vous être utile.

Enfin, si vous souhaitez plus particulièrement utiliser de la
documentation de langue anglaise (dont une part est présentée dans les
pages indiquées plus haut), voici quelques pages donnant de nombreux
liens :

-   [une page du site du TUG](https://tug.org/interest.html) ;
-   [une page de l'université de Cambridge](http://www-h.eng.cam.ac.uk/help/tpl/textprocessing/LaTeX_intro.html) ;
-   le [(La)TeX Navigator](https://mirror.gutenberg-asso.fr/tex.loria.fr/). Si cette
    ressource est désormais obsolète, elle donne cependant un bon nombre de liens.

Enfin, cette FAQ met à disposition une question traitant de traductions 
des termes techniques de l'univers de TeX : "[](/1_generalites/documentation/comment_traduire_ce_terme)".


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```