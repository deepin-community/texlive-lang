---
myst:
  html_meta:
    keywords: LaTeX,glossaire,vocabulaire,distribution
---
# Qu'est-ce qu'une distribution TeX ?

Une *distribution TeX* (ou *système TeX*) fournit une collection structurée de
logiciels liés à TeX. Généralement, une distribution TeX comprend :

- un ensemble d'exécutables TeX centraux tels que `tex` et `latex` ;
- diverses polices optimisées pour une utilisation avec TeX ;
- des programmes d'aide tels que le traitement de bases de données
  bibliographiques BibTeX, des éditeurs, des environnements de développement
  intégrés, des programmes de conversion de format de fichier ;
- de nombreuses extensions LaTeX ;
- des outils de configuration ;
- et tout autre complément que le distributeur choisit d'inclure.

Les distributions TeX les plus courantes sont :

- [TeX Live](https://tug.org/texlive/) qui est multiplateforme ;
- [MacTeX](https://tug.org/mactex/) (destiné à Mac) qui ajoute entre autres à
  TeX Live un installateur natif pour macOS et d’autres applications Mac ;
- [MiKTeX](https://miktex.org/) qui est multiplateforme (mais tout de même
  plutôt orienté vers Windows) ;

% (Commentaire) Est-il nécessaire de parler des distributions historiques ?
% - et historiquement s'y ajoutent [ProTeXt](https://www.tug.org/protext/),
%   [ozTeX](https://www.trevorrow.com/oztex/),
%   [CMacTeX](https://www.kiffe.com/cmactex.html) et
%   [teTeX](https://www.tug.org/tetex/).
  
Certaines distributions TeX ciblent un système d'exploitation ou une
architecture de processeur spécifiques tandis que d'autres fonctionnent sur
plusieurs plates-formes. Les distributions TeX peuvent être
[gratuites](/6_distributions/installation/trouver_les_sources_pour_les_differents_systemes_d_exploitation2)
(c'est le cas de TeX Live, MacTeX et MiKTeX) comme
[payantes](/6_distributions/installation/implementations_commerciales).

Ce sujet est plus largement abordé dans la sous-partie
« [](/6_distributions/installation/start) » de la partie
« [](/6_distributions/start) » de cette FAQ.

:::{sources}
- [Things with « TeX » in the name](faquk:FAQ-texthings)
- [Leçon *Travailler avec LaTeX* de learnlatex.org](https://www.learnlatex.org/fr/lesson-02)
:::
