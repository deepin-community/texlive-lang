---
myst:
  html_meta:
    keywords: TeX,LaTeX,Eplain,définition,format
---
# Qu'est-ce que Plain TeX ?

Plain TeX (qui peut être traduit en « TeX simple ») est le premier [format](/1_generalites/glossaire/format) de [TeX](/1_generalites/glossaire/tex), écrit par Donald Knuth lui-même. Ce format contient environ 600 commandes complétant et simplifiant l'utilisation des 300 primitives de TeX.
