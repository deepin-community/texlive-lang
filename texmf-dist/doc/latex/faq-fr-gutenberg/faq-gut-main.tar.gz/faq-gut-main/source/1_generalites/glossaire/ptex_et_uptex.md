---
myst:
  html_meta:
    keywords: LaTeX,japonais,chinois,idéogrammes,composition verticale,Unicode,UTF-8,langues orientales,document multilingue
---
# Que sont pTeX et upTeX ?

Le programme [pTeX](ctanpkg:ptex) ajoute à [TeX](/1_generalites/glossaire/tex)
des fonctionnalités pour composer des documents en japonais,
notamment le support de la composition verticale.
[pLaTeXe](ctanpkg:platex) y ajoute les macros nécessaires
pour en faire un environnement [LaTeX](/1_generalites/glossaire/latex).
[Son développement se poursuit](https://github.com/texjporg/tex-jp-build).

[upTeX](ctanpkg:uptex) et [upLaTeXe](ctanpkg:uplatex) sont des versions Unicode de pTeX.
Ils supportent également le chinois simplifié, le chinois traditionnel et le coréen,
et peuvent compiler des documents écrits en caractères latins, grecs ou cyrilliques
(avec `\inputenc{utf8}` [si nécessaire](/3_composition/langues/latex_et_l_utf8) et l'extension <ctanpkg:babel>).

:::{sources}
<http://www.t-lab.opal.ne.jp/tex/uptex_en.html>
:::
