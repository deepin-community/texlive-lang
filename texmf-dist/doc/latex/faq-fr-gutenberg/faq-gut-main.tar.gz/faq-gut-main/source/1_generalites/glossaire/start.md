---
myst:
  html_meta:
    keywords: LaTeX,TeX,glossaire,vocabulaire,qu'est-ce que TeX,définitions,comprendre TeX,la base de TeX
---

# Glossaire de TeX


Cette section définit quelques termes courants dans le monde de TeX et
TeX.

## TeX et ses formats

-   [Qu'est-ce que TeX ?](/1_generalites/glossaire/tex)
-   [Qu'est-ce qu'un format de TeX ?](/1_generalites/glossaire/format)
-   [Qu'est-ce que Plain TeX ?](/1_generalites/glossaire/plain_tex)
-   [Qu'est-ce que LaTeX ?](/1_generalites/glossaire/latex)
-   [Qu'est-ce que LaTeX2ε ?](/1_generalites/glossaire/latex2e)
-   [Qu'est-ce que ConTeXt ?](/1_generalites/glossaire/context)
-   [Qu'est-ce que Texinfo ?](/1_generalites/glossaire/texinfo)
-   [Qu'est-ce qu'Eplain ?](/1_generalites/glossaire/eplain)

## TeX et ses moteurs

-   [Qu'est-ce qu'un moteur ?](/1_generalites/glossaire/moteur)
-   [Qu'est-ce que pdfTeX ?](/1_generalites/glossaire/pdftex)
-   [Qu'est ce que XeTeX ?](/1_generalites/glossaire/xetex)
-   [Qu'est-ce que LuaTeX ?](/1_generalites/glossaire/luatex)
-   [Qu'est-ce qu'ε-TeX ?](/1_generalites/glossaire/etex)
-   [Que sont pTeX et upTeX ?](/1_generalites/glossaire/ptex_et_uptex)

## Extensions de TeX

-   [Que sont AMS-TeX et AMS-LaTeX ?](/1_generalites/glossaire/ams-tex_et_ams-latex)

## Logiciels autour de TeX

-   [Qu'est-ce que MetaPost ?](/1_generalites/glossaire/metapost)
-   [Qu'est-ce que MetaFont ?](/1_generalites/glossaire/metafont)

## Autres termes courants

-   [Qu'est-ce qu'une distribution TeX ?](/1_generalites/glossaire/distribution)
-   [Qu'est-ce que le CTAN ?](/1_generalites/glossaire/ctan)
-   [Y-a-t'il d'autres trucs-TeX ?](/1_generalites/glossaire/xx-tex)

```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
