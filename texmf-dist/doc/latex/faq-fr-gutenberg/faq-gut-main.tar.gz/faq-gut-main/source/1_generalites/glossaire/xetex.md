---
myst:
  html_meta:
    keywords: LaTeX,UTF8,Unicode,XeTeX,utiliser les polices système,OpenType
---
# Qu'est ce que XeTeX ?

## Qu'est ce que XeTeX ?

[XeTeX](https://xetex.sourceforge.net/) est un moteur Unicode TeX qui peut charger les polices système directement en utilisant la bibliothèque [HarfBuzz](wpfr:HarfBuzz), qui est intégrée. Pour ce faire, la primitive `\font` et quelques autres primitives TeX ont été étendues. Pour la plupart des utilisateurs finaux de LaTeX, ces subtilités sont transparentes, le noyau LaTeX et l'extension <ctanpkg:fontspec> fournissant des interfaces.

Le moteur standard [pdfTeX](/1_generalites/glossaire/pdftex) est entièrement rétrocompatible avec TeX. En tant que tel, il reste un système 8 bits utilisant des [métriques de polices dédiées](/5_fichiers/formats/fontes/que_sont_les_fichiers_tfm). En revanche, le moteur `XeTeX` est basé sur Unicode et capable de charger des polices système standards (OpenType). En interne, il se distingue de [LuaTeX](/1_generalites/glossaire/luatex) : des résultats similaires sont atteints en utilisant des philosophies très différentes (avec des avantages différents à la clef).

Tout comme TeX, `XeTeX` ne produit pas directement de sortie PDF mais fonctionne *via* un format intermédiaire, XDV (*eXtended DVI*). Contrairement au format classique [DVI](/5_fichiers/formats/dvi/qu_est_qu_un_fichier_dvi) produit par TeX, les fichiers XDV ne peuvent pas être visualisés directement et sont normalement convertis directement en PDF lors de l'exécution de `xetex`. Cette conversion est réalisée `xdvpdfmx`.

## Qu'est ce que XeLaTeX ?

XeLaTeX est, tout naturellement, le [format LaTeX](/1_generalites/glossaire/latex) utilisé avec le moteur XeTeX.

:::{note}
« XeTeX » se prononce [ziːtɛk] (cf. [](/1_generalites/bases/comment_prononcer_tex) »).
:::

:::{sources}
- [What are XeTeX and LuaTeX?](faquk:FAQ-xetex-luatex)
- [XeTeX](wpfr:XeTeX) sur Wikipedia.
- [Interview de Jonathan Kew](https://tug.org/interviews/kew.html) (en anglais),
- [Proper pronunciation of XeTeX, XeLaTeX](https://tex.stackexchange.com/questions/274617/proper-pronunciation-of-xetex-xelatex).
:::
