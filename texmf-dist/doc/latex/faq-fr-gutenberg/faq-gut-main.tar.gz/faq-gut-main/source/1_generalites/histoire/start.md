---
myst:
  html_meta:
    keywords: LaTeX,histoire,développement de TeX
---

# Histoire de TeX et LaTeX


Cette section regroupe des questions portant sur l'histoire de TeX et
LaTeX. Elle évoque également une thématique importante : ce qui est
devenu obsolète au regard de l'évolution de ces logiciels.

## Développement de TeX et LaTeX

-   [Quelle est l'histoire de TeX et LaTeX ?](/1_generalites/histoire/histoire_de_tex_et_latex)
-   [Quel est l'avenir de TeX ?](/1_generalites/histoire/quel_futur_pour_tex)
-   [Que sont LaTeX3 et le « LaTeX Project » ?](/1_generalites/histoire/c_est_quoi_latex3)
-   [Quels sont les projets de développement de TeX ?](/1_generalites/histoire/developpement_du_moteur_tex)
-   [Qu'est devenu initex ?](/1_generalites/histoire/qu_est_devenu_initex)
-   [TeX a-t-il subi le bug de l'an 2000 ?](/1_generalites/histoire/tex_et_le_bug_de_l_an_2000)

## Éléments devenus obsolètes

-   [Quelles extensions sont considérées comme obsolètes ? Par quoi les
    remplacer ?](/1_generalites/histoire/liste_des_packages_obsoletes)


:::{todo}
Les liens qui suivent ne sont pas classés.
:::

-   [](/1_generalites/histoire/extensions_disparues)

```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
