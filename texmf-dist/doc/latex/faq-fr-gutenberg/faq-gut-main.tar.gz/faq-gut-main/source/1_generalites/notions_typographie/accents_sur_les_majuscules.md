---
myst:
  html_meta:
    keywords: LaTeX,typographie
---
# Doit-on mettre les accents sur les majuscules ?

Oui ! Au début de l'informatique, le codage sur 7 bits a obligé à réduire le nombre de caractères différents utilisables par les ordinateurs, et les majuscules accentuées ont paru accessoires aux concepteurs (américains) de l'époque. Ce n'est plus actualité. De plus, la saisie des accents sur n'importe quelle lettre est très simple en LaTeX.

Voici un exemple :

```
\begin{description}
\item[Au moyen d'une commande :] PALAIS DES CONGR\`ES
\item[Ou bien directement :] PALAIS DES CONGRÈS
\end{description}
```

Une réponse plus détaillée est donnée sur le [site Antidote](https://www.antidote.info/fr/blogue/enquetes/faut-il-accentuer-les-majuscules-et-les-capitales).
