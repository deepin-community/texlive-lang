---
myst:
  html_meta:
    keywords: LaTeX,typographie,règles typographiques,bien présenter un document
---

# Notions de typographie


LaTeX est réputé pour la production de documents de niveau
universitaire, notamment en mathématiques. Cependant, sa qualité de
rendu typographique est un point fort.

En français, les principales normes typographiques sont prises en charge
automatiquement par LaTeX, sans qu'il soit besoin d'être spécialiste
en orthotypographie, grâce aux extensions <ctanpkg:babel> ou
<ctanpkg:polyglossia>.

Il est néanmoins conseillé de se familiariser avec le sujet de la
typographie pour utiliser correctement LaTeX et comprendre ce qu'il
fait. Vous trouverez dans cette FAQ sur le sujet de la typographie :

-   une [liste de livres](/1_generalites/documentation/livres/documents_sur_la_typographie) ;
-   une [liste de documents en ligne](/1_generalites/documentation/documents/documents_sur_la_typographie).

Les questions de cette section traitent de certains sujets de
typographie (des rappels de notions courantes) ou de la manière
d'utiliser LaTeX pour améliorer la typographie d'un document.

## Points particuliers

-   [](/1_generalites/notions_typographie/accents_sur_les_majuscules)
-   [](/1_generalites/notions_typographie/espaces_autour_ponctuation)
-   [](/1_generalites/notions_typographie/ponctuation_dans_une_enumeration)

## Fonctionnement de LaTeX

-   [](/1_generalites/notions_typographie/microtype)
-   [](/1_generalites/notions_typographie/correction_italique)
```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
