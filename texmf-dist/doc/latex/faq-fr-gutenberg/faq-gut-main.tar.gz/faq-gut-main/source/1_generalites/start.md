---
myst:
  html_meta:
    keywords: LaTeX, TeX, généralités
---

# <i class="fa-solid fa-compass"></i> Généralités


Ce thème regroupe toutes les questions traitant des grands principes de
TeX et LaTeX :

-   les [bases](/1_generalites/bases/start) forment un ensemble de
    questions dédiées aux débutants ;
-   la [documentation](/1_generalites/documentation/start) détaille les
    très nombreuses sources d'information extérieures à cette FAQ ;
-   le [glossaire](/1_generalites/glossaire/start) définit certains
    termes et noms usuels du domaine ;
-   [l'histoire](/1_generalites/histoire/start) donne une idée de
    l'évolution des logiciels (en précisant ce qui est devenu obsolète) ;
-   et s'ajoute à tout cela un sujet très lié à l'utilisation de ces
    logiciels : les [notions de
    typographie](/1_generalites/notions_typographie/start).

Deux questions particulièrement utiles pour les débutants sont placées ici :

-   [](/1_generalites/bases/comment_faire_ses_premiers_pas)
-   [](/1_generalites/documentation/listes_de_discussion/groupes_d_utilisateurs)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```