---
myst:
  html_meta:
    keywords: LaTeX, programmation, compilation, \jobname
---

# Comment récupérer le nom du fichier compilé ?

La commande `\jobname` retourne le nom (sans son extension) du fichier maître 
en cours de traitement.

```
\documentclass[french]{article}
  \usepackage[T1]{fontenc}    % Encodage T1 (adapté au français)
  \usepackage{lmodern}        % Caractères plus lisibles
  \usepackage{babel}          % Réglages linguistiques (avec french)

\begin{document}
Le fichier source de ce document PDF s'appelle \texttt{\jobname.tex}.
\end{document}
```