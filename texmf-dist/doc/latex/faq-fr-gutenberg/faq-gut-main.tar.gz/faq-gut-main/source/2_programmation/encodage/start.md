---
myst:
  html_meta:
    keywords: LaTeX, programmation, encodage
---

# Encodage

Cette section détaille le sujet des
[encodages](https://fr.wikipedia.org/wiki/Codage_des_caractères) 
(en entrée comme en sortie).

- [](/2_programmation/encodage/notion_d_encodage)
- [](/2_programmation/encodage/pourquoi_m_embeter_avec_inputenc_et_fontenc)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```