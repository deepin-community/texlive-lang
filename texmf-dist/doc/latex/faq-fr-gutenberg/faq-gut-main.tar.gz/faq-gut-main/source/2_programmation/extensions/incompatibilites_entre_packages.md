---
myst:
  html_meta:
    keywords: LaTeX, programmation, conflits entre extensions, préambule, clash entre extensions, clash entre packageq, ordre des extensions, ordre des packages
---
# Comment résoudre les incompatibilités entre extensions ?

Les problèmes surviennent, en général, lorsque deux extensions s'attaquent à la redéfinition de la même commande. Par exemple, si vous choisissez d'inclure à la fois les extensions <ctanpkg:bibentry> et <ctanpkg:backref>, vous allez inévitablement rencontrer des problèmes, puisque l'une et l'autre redéfinissent la commande `\bibitem` (en utilisant d'ailleurs tous les deux la commande interne `\BR@bibitem`).

Dans certains cas, il suffit de permuter l'ordre de chargement de certaines extensions. Il n'y a pas de règle générale, cependant.

:::{todo} Compléter la page.
:::

## Conflits connus avec l'extension <ctanpkg:hyperref>

:::{todo} Compléter.
:::


## Conflits connus avec l'extension <ctanpkg:amsmath>

L'extension <ctanpkg:lmodern> peut créer des problèmes d'affichage pour les grands opérateurs si elle est utilisée avec <ctanpkg:amsmath>, comme l'illustre la question "[](/4_domaines_specialises/mathematiques/symboles/polices/tailles_des_symboles_en_mode_mathematique.md)". L'extension <ctanpkg:exscale> corrige ce point.

:::{todo} Compléter.
:::


## Conflits connus avec l'extension <ctanpkg:mathtools>

L'extension <ctanpkg:lmodern> cause la même difficulté à <ctanpkg:mathtools> qu'à <ctanpkg:amsmath> : la solution est identique.

:::{todo} Compléter.
:::


:::{sources}
- [Packages that need to be included in a specific order](https://tex.stackexchange.com/questions/3090/packages-that-need-to-be-included-in-a-specific-order),
- [Which packages should be loaded after hyperref instead of before?](https://tex.stackexchange.com/questions/1863/which-packages-should-be-loaded-after-hyperref-instead-of-before)
:::
