---
myst:
  html_meta:
    keywords: LaTeX, programmation, classes, extensions, packages
---

# Extensions et classes

Cette section détaille le sujet des extensions (aussi nommés *packages*) 
et des classes de manière générale. L'utilisation de telle ou telle extension 
ou classe en fonction des besoins est analysée dans les grandes sections thématiques 
de cette FAQ ([programmation](/2_programmation/start), 
[composition de documents](/3_composition/start) et 
[domaines spécialisés](/4_domaines_specialises/start)).


## Gestion des classes et extensions

-   [](/2_programmation/extensions/que_sont_les_classes_et_packages)
-   [](/2_programmation/extensions/creer_sa_propre_classe)
-   [](/2_programmation/extensions/apprendre_a_ecrire_des_classes_et_des_packages)
-   [](/2_programmation/extensions/installer_un_package)
-   [](/2_programmation/extensions/options_de_packages)
-   [](/2_programmation/extensions/incompatibilites_entre_packages)

## Classes et extensions particulières

-   [](/2_programmation/extensions/classe_minimal)

Le lecteur curieux est également invité à lire des questions traitant 
de la [documentation des extensions](/1_generalites/documentation/documents/documents_extensions/start) 
pour avoir une vision complète du sujet.


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```