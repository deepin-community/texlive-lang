---
myst:
  html_meta:
    keywords: LaTeX, programmation, commandes, macros, arobase, at dans les noms de commandes, A rond, commandes internes de LaTeX
---
# Que fait `@` dans les noms de commandes ?

Ce sujet est développé dans la question "[](/2_programmation/macros/makeatletter_et_makeatother)".
