---
myst:
  html_meta:
    keywords: LaTeX, programmation, commandes, macros, instructions spéciales, pilote
---
# Que fait `\special` ?

Cette commande permet à TeX d'envoyer des instructions particulières (non TeX) à un pilote (*driver*) sans les interpréter (par exemple un [pilote DVI](/5_fichiers/formats/dvi/qu_est_qu_un_pilote_dvi)). Les instructions ainsi passées sont généralement dépendantes du pilote qui, lui, saura les interpréter. L'utilisateur n'a en général pas à se soucier de cette commande (`\special`). Elle rend par ailleurs le document dépendant de la plate-forme de travail.

Un exemple d'extension utilisant intensivement ce mécanisme : [PSTricks](ctanpkg:pstricks-base). Ses commandes de dessin encapsulent du code PostScript dans des commandes `\special`, pour les faire parvenir au [logiciel de visualisation](/6_distributions/visualisateurs/visualisateurs_postscript) ([Ghostview](wpfr:Ghostview) ou autre) ou à l'imprimante.

La question "[](/3_composition/document/document_version/identifier_une_version_provisoire.md)" donne un exemple d'utilisation en lien avec du code Postscript.
