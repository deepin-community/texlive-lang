---
myst:
  html_meta:
    keywords: programmation, compilation, commandes, encodage, extensions, classes, erreurs, 
              syntaxe
---

# <i class="fa-solid fa-code"></i> Programmation

Ce thème regroupe toutes les questions traitant de la programmation avec TeX,
LaTeX et leurs satellites. Elles sont organisées dans différents sections 
traitant de :

-   la [syntaxe](/2_programmation/syntaxe/start) du code avec, entre autres notions 
    particulières, le [préambule](/2_programmation/syntaxe/preambule), 
    les [boîtes](/2_programmation/syntaxe/boites/start),
    les [compteurs](/2_programmation/syntaxe/compteurs/start),
    les [catcodes](/2_programmation/syntaxe/catcodes/start),
    la [protection](/2_programmation/syntaxe/c_est_quoi_la_protection) ;
-   la définition des [commandes et environnements](/2_programmation/macros/start) et 
    quelques commandes importantes ;
-   la création et l'utilisation des 
    [extensions et classes](/2_programmation/extensions/start) ;
-   la gestion des [encodages](/2_programmation/encodage/start) ;
-   la mécanique de la [compilation](/2_programmation/compilation/start) ;
-   et enfin, les [messages d'erreur de LaTeX](/2_programmation/erreurs/start), 
    parfois un peu trop sybillins.


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```