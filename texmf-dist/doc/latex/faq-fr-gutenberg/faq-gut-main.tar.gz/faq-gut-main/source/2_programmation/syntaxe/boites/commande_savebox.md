---
myst:
  html_meta:
    keywords: LaTeX,enregistrer du contenu LaTeX,enregistrer une box,utiliser une box LaTeX
---
# À quoi sert la commande `\savebox` ?

- Elle sert à définir des boîtes afin de les réutiliser ultérieurement. Une
  boîte doit être déclarée avant d'être utilisée. Par exemple :

```
\newsavebox{\faq}
\savebox{\faq}{FAQ de {\ttfamily fr.comp.text.tex}}
Ceci est la \usebox{\faq}.
```
