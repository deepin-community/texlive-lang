---
myst:
  html_meta:
    keywords: LaTeX,TeX,boîtes
---

# Boîtes





:::{todo}
Les liens qui suivent ne sont pas classés.
:::

-   [](/2_programmation/syntaxe/boites/commande_savebox)
-   [](/2_programmation/syntaxe/boites/comprendre_le_modele_de_boites)

```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
