---
myst:
  html_meta:
    keywords: commandes de LaTeX,liste des catcodes,codes de catégorie,catégories de caractères
---

# Les catcodes


Cette section, au sein de celle de la [syntaxe](../start.md), détaille le sujet des codes de catégories ou catcodes.

-   [Que sont les catcodes ?](/2_programmation/syntaxe/catcodes/que_sont_les_catcodes)

```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
