---
myst:
  html_meta:
    keywords: LaTeX,latex,compteurs
---

# Compteurs


Cette section détaille le sujet des compteurs (servant le plus souvent
aux numéros des sections, numéros des pages\...).

## Création de compteurs

-   [Comment gérer des compteurs ?](/2_programmation/syntaxe/compteurs/utiliser_des_compteurs)
-   [Comment visualiser des compteurs ?](/2_programmation/syntaxe/compteurs/visualiser_des_compteurs)
-   [Comment définir un compteur dépendant d'un autre compteur ?](/2_programmation/syntaxe/compteurs/compteurs_maitres_et_esclaves)
-   [Comment utiliser des étiquettes comme des valeurs de compteur ?](/2_programmation/syntaxe/compteurs/utiliser_des_labels_comme_compteurs2)
-   [Comment redéfinir les commandes de compteur `\the⟨truc⟩` ?](/2_programmation/syntaxe/compteurs/comment_fonctionnent_les_compteurs)

## Style des compteurs

-   [Quels sont les différents styles de compteur ?](/2_programmation/syntaxe/compteurs/les_differents_compteurs)

```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```
