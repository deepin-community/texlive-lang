---
myst:
  html_meta:
    keywords: LaTeX, programmation, syntaxe
---

# Syntaxe

Cette section détaille le sujet des règles de syntaxe des documents TeX
et LaTeX.


## Règles de syntaxe

-   [](/2_programmation/syntaxe/commentaires/mettre_en_commentaire_une_partie_du_source)
-   [](/2_programmation/syntaxe/commentaires/compilation_conditionnelle_et_commentaires)
-   [](/2_programmation/syntaxe/accolades_incoherentes)


## Structure syntaxique d'un fichier

-   [](/2_programmation/syntaxe/preambule)
-   [](/2_programmation/syntaxe/que_contient_le_fichier_source)


## Validation de syntaxe

-   [](/2_programmation/syntaxe/verificateurs_de_syntaxe)
-   [](/2_programmation/syntaxe/ameliorer_la_qualite_d_un_code_latex)

:::{todo}
Les liens qui suivent ne sont pas classés.
:::

-   [](/2_programmation/syntaxe/c_est_quoi_la_protection)
-   [](/2_programmation/syntaxe/conditions_dans_un_style)
-   [](/2_programmation/syntaxe/iterations)
-   [](/2_programmation/syntaxe/mode_verbatim_dans_une_macro)
-   [](/2_programmation/syntaxe/rendre_inactif_un_caractere)
-   [](/2_programmation/syntaxe/repeter_une_commande_n_fois)
-   [](/2_programmation/syntaxe/repeter_une_commande_pour_chaque_element_d_une_liste)
-   [](/2_programmation/syntaxe/visualiser_des_parametres)
-   [](/2_programmation/syntaxe/longueurs/start)
-   [](/2_programmation/syntaxe/catcodes/start)
-   [](/2_programmation/syntaxe/boites/start)
-   [](/2_programmation/syntaxe/compteurs/start)
-   [](/2_programmation/syntaxe/registres/start)
-   [](/2_programmation/syntaxe/commentaires/start)
-   [](/2_programmation/syntaxe/convertir_du_latex_en_plain_tex)
-   [](/2_programmation/syntaxe/rediger_un_rapport_de_bug)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```