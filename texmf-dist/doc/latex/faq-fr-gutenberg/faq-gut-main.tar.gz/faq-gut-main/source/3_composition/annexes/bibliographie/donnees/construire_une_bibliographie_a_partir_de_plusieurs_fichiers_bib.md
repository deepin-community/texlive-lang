---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, données
---

# Comment construire une bibliographie à partir de plusieurs fichiers `.bib` ?

En suivant la méthode de construction d'une bibliographie avec BibTeX telle que
décrite à la question 
"[](/3_composition/annexes/bibliographie/donnees/construire_un_fichier_bibtex)",
vous pourrez noter que la commande `\bibliography` peut accepter 
plusieurs noms de fichiers `.bib`. 

:::{noedit}
\bibliography{biblioA, biblioB, biblioC}
:::


:::{todo} Ajouter un exemple avec filecontents
:::