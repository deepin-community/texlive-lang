---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, données
              entrées bibliographiques
---

# Données bibliographiques

Cette section détaille le sujet des données bibliographiques 
au format `.bib`. La syntaxe de ces données est décrite à la 
section [Syntaxe des données bibliographiques](/3_composition/annexes/bibliographie/syntaxe/start).


## Gestion des fichiers `.bib`

-   [](/3_composition/annexes/bibliographie/donnees/construire_un_fichier_bibtex)
-   [](/3_composition/annexes/bibliographie/donnees/reconstruire_un_fichier_bib)
-   [](/3_composition/annexes/bibliographie/donnees/construire_une_bibliographie_a_partir_de_plusieurs_fichiers_bib)


## Importation et exportation des fichiers `.bib`

-   [](/3_composition/annexes/bibliographie/donnees/produire_un_fichier_html_a_partir_d_une_bibliographie)
-   [](/3_composition/annexes/bibliographie/donnees/zotero_et_latex)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```