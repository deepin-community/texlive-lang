---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, références
---

# Références à la bibliographie

Cette section détaille le sujet des références placées dans le texte 
pour renvoyer vers la 
[bibliographies](https://fr.wikipedia.org/wiki/Bibliographie).


## Gestion des références

-   [](/3_composition/annexes/bibliographie/references/faire_reference_a_un_document)
-   [](/3_composition/annexes/bibliographie/references/citer_un_document_sans_y_faire_reference)
-   [](/3_composition/annexes/bibliographie/references/configurer_la_commande)
-   [](/3_composition/annexes/bibliographie/references/grouper_des_references_bibligraphiques_multiples)


## Références avec un positionnement particulier

-   [](/3_composition/annexes/bibliographie/references/citer_une_reference_dans_une_liste)
-   [](/3_composition/annexes/bibliographie/references/reference_bibliographique_dans_la_legende_d_une_figure)
-   [](/3_composition/annexes/bibliographie/references/mettre_une_reference_bibliographique_en_note_de_bas_de_page)
-   [](/3_composition/annexes/bibliographie/references/references_biblio_multiples)
-   [](/3_composition/annexes/bibliographie/references/inserer_les_references_biblio_dans_le_texte)


## Cas particulier de la bibliographie faisant référence au texte

-   [](/3_composition/annexes/bibliographie/references/referencer_les_pages_d_appel_d_une_reference_bibliographique)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```