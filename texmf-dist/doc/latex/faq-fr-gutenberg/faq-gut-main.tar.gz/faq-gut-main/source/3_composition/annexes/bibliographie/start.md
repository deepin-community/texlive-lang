---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, bibliographies
---

# Bibliographies

Cette section détaille le sujet des
[bibliographies](https://fr.wikipedia.org/wiki/Bibliographie),
[annexes](/3_composition/annexes/start) qui donnent les informations
bibliographiques de différentes références évoquées (ou pas) dans le
document. 

Certains points sont traités dans des sections dédiées :

-   [les références à la bibliographie](/3_composition/annexes/bibliographie/references/start) ;
-   [le style de la bibliographie](/3_composition/annexes/bibliographie/style/start) 
    (son titre, son espacement...) ;
-   [les données bibliographiques](/3_composition/annexes/bibliographie/donnees/start),
    autrement dit les entrées présentées dans le format de fichier `.bib` ;
-   [la syntaxe des entrées bibliographiques](/3_composition/annexes/bibliographie/syntaxe/start) ;
-   [le style des éléments de la bibliographie](/3_composition/annexes/bibliographie/style_bst/start) 
    (avec les fichiers `.bst`).


## Création de bibliographie

-   [](/3_composition/annexes/bibliographie/construire_une_bibliographie)
-   [](/3_composition/annexes/bibliographie/remplacer_bibtex)
-   [](/3_composition/annexes/bibliographie/utiliser_bibtex_avec_plain_tex)
-   [](/3_composition/annexes/bibliographie/afficher_toutes_les_entrees_d_un_fichier_bib)
-   [](/3_composition/annexes/bibliographie/trier_une_bibliographie)


## Bibliographies multiples

-   [](/3_composition/annexes/bibliographie/obtenir_plusieurs_bibliographies_dans_un_document)
-   [](/3_composition/annexes/bibliographie/bibliographies_par_chapitre)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```