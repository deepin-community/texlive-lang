---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, 
              style de la bibliographie, table des matières
---

# Comment référencer la bibliographie dans la table des matières ?

La question 
"[](/3_composition/annexes/tables/ajouter_une_entree_a_une_table_des_matieres)"
aborde ce cas particulier.