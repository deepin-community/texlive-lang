---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, 
              style de la bibliographie
---

# Style de la bibliographie

Cette section détaille le sujet du style de la 
[bibliographie](/3_composition/annexes/bibliographie/start) (hors traitement 
par des [fichiers `.bst`](/3_composition/annexes/bibliographie/style_bst/start))


## Titre de la bibliographie

-   [](/3_composition/annexes/bibliographie/style/referencer_la_bibliographie_dans_la_table_des_matieres)
-   [](/3_composition/annexes/bibliographie/style/changer_le_titre_de_la_bibliographie)


## Espacement dans la bibliographie

-   [](/3_composition/annexes/bibliographie/style/compacter_une_bibliographie)
-   [](/3_composition/annexes/bibliographie/style/changer_l_espacement_entre_les_references_bibliographiques)


## Formats des entrées de la bibliographie 

-   [](/3_composition/annexes/bibliographie/style/formats_des_references_numeriques_dans_les_bibliographies)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```