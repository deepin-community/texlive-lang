---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie,
              style des entrées bibliographiques,
---

# Comment changer de langue dans une bibliographie ?

:::{todo} Ajouter des exemples
:::

## Avec des styles bibliographiques dédiés

Il existe des versions francisées des styles bibliographiques, disponibles 
sur <ctanpkg:bib-fr>. Ces versions traduisent principalement `“` et `”` 
en `\og{}` et `\fg`{}, les noms des mois et quelques autres petites choses. 
Cependant, elles ne changent pas les règles typographiques appliquées 
au document, notamment les règles de césure.


## Avec l'extension <ctanpkg:mlbib>

L'extension <ctanpkg:mlbib> permet de gérer des bibliographies multilingues.


## Avec des réglages linguistiques généraux

Les éléments d'une bibliographie étant des paragraphes, on peut modifier 
localement les règles typographiques à appliquer pour chaque entrée. Ce point 
est détaillé dans la question
"[](/3_composition/langues/composer_un_document_latex_en_francais)".