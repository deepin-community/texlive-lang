---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie,
              style des entrées bibliographiques
---

# Style des entrées de la bibliographie

Cette section détaille le sujet du style de la 
[bibliographie](/3_composition/annexes/bibliographie/start). Les réglages 
pouvant être traités hors fichiers de style sont évoqués à la section
[Style de la bibliographie](/3_composition/annexes/bibliographie//style/start).


## Choix des styles BibTeX

-   [](/3_composition/annexes/bibliographie/style_bst/choisir_un_style_de_bibliographie)
-   [](/3_composition/annexes/bibliographie/style_bst/trouver_des_styles_de_bibliographie)
-   [](/3_composition/annexes/bibliographie/style_bst/changer_le_style_de_la_bibliographie)
-   [](/3_composition/annexes/bibliographie/style_bst/supprimer_la_virgule_en_trop_dans_une_liste_d_auteurs)
-   [](/3_composition/annexes/bibliographie/style_bst/probleme_avec_le_style_unsrt)


## Création et correction de styles BibTeX

-   [](/3_composition/annexes/bibliographie/style_bst/creer_un_style_de_bibliographie)
-   [](/3_composition/annexes/bibliographie/style_bst/generer_l_expression_et_al_automatiquement)


## Cas des styles pour l'international

-   [](/3_composition/annexes/bibliographie/style_bst/bibliographies_internationales)
-   [](/3_composition/annexes/bibliographie/style_bst/changer_de_langue_dans_une_bibliographie)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```