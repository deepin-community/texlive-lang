---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie, syntaxe,
              entrées bibliographiques
---

# Syntaxe des données bibliographiques

Cette section détaille le sujet du format des champs dans les fichiers
de [données bibliographiques](/3_composition/annexes/bibliographie/donnees/start) 
au format `.bib`. 


## Champs disponibles pour les données bibliographiques

-   [](/3_composition/annexes/bibliographie/syntaxe/citer_une_url)
-   [](/3_composition/annexes/bibliographie/syntaxe/faire_reference_a_une_these)
-   [](/3_composition/annexes/bibliographie/syntaxe/faire_des_references_bibliographiques_croisees)


## Syntaxe de certains champs

### Cas du champ `author`

-   [](/3_composition/annexes/bibliographie/syntaxe/liste_d_auteurs)
-   [](/3_composition/annexes/bibliographie/syntaxe/initiales_multiples_avec_bibtex)
-   [](/3_composition/annexes/bibliographie/syntaxe/trier_des_noms_avec_prefixes)
-   [](/3_composition/annexes/bibliographie/syntaxe/utiliser_les_deux_premieres_lettres_du_prenom_d_un_auteur)


### Autres champs

-   [](/3_composition/annexes/bibliographie/syntaxe/accents_dans_les_bibliographies)
-   [](/3_composition/annexes/bibliographie/syntaxe/conserver_les_majuscules_dans_les_titres)
-   [](/3_composition/annexes/bibliographie/syntaxe/erreur_string_too_long_avec_bibtex)


```{toctree}
:glob: true
:maxdepth: 1
:hidden:

*/start
*
```