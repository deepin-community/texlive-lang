---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, bibliographie
---

# Comment utiliser BibTeX avec Plain TeX ?

Le fichier `btxmac.tex`, qui fait partie des fichiers du 
[format](/1_generalites/glossaire/format) [Eplain](ctanpkg:eplain), contient
des commandes et de la documentation pour utiliser BibTeX avec Plain TeX, 
soit directement, soit avec [Eplain](/1_generalites/glossaire/eplain).


:::{sources}
[Using BibTeX with Plain TeX](faquk:FAQ-bibplain)
:::