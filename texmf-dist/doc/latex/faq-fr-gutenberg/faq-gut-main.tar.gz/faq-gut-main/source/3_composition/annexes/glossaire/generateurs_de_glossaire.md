---
myst:
  html_meta:
    keywords: LaTeX, composition, annexes, glossaire, makeindex, xindy, BibTeX
---

# Quels sont les générateurs de glossaire ?

## Les programmes <ctanpkg:makeindex> ou <ctanpkg:xindy>

Les programmes <ctanpkg:makeindex> et <ctanpkg:xindy> sont les plus couramment
utilisés.


## Le programme [GloTeX](ctanpkg:glotex)

Le programme [GloTeX](ctanpkg:glotex) permet de créer un glossaire 
à partir d'une base de données. Cela permet de réutiliser les définitions 
et d'avoir des glossaires cohérents d'un document à un autre.


## Le programme <ctanpkg:glosstex>

Le programme <ctanpkg:glosstex> avec l'extension du même nom fonctionne 
lui aussi à partir d'une base de données. Il permet de générer 
plusieurs listes (définitions, acronymes...).


## L'extension <ctanpkg:gloss> avec BibTeX

L'extension <ctanpkg:gloss> utilise également des bases de données pour générer
le contenu du glossaire, mais elle utilise BibTeX pour générer ce contenu.