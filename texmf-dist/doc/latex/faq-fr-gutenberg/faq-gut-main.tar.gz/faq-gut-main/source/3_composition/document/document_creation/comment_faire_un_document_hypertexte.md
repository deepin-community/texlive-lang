---
myst:
  html_meta:
    keywords: LaTeX, composition, document, création d'un document, hypertexte,
              hyperref, HTML, conversion, LaTeX pour le web
---

# Comment obtenir un document hypertexte avec (La)TeX ?

Si vous voulez faire un document hypertexte en ligne avec une source TeX 
ou LaTeX, il y a actuellement trois possibilités à considérer.


## Avec l'extension <ctanpkg:hyperref>

Voici la solution la plus classique : vous partez d'une source LaTeX et 
utilisez `pdfTeX`, [XeTeX](/1_generalites/glossaire/xetex) ou
[LuaTeX](/1_generalites/glossaire/luatex) pour produire des PDF,
tout en vous servant de l'extension <ctanpkg:hyperref> pour construire des
hyperliens.

Des éléments complémentaires sont donnés à la question 
"[](/3_composition/texte/renvois/composer_des_liens_hypertexte)".


## Avec une conversion de LaTeX en HTML

Vous pouvez partir d'une source TeX ou LaTeX et utiliser une des nombreuses
techniques pour la traduire (plus ou moins) directement en HTML évoquées
à la question "[](/5_fichiers/formats/xml/convertir_du_latex_en_html)".


## Avec <ctanpkg:texinfo>

Vous pouvez partir d'une source [`texinfo`](/1_generalites/glossaire/texinfo)
et utiliser le visualiseur `info` ou bien convertir la source <ctanpkg:texinfo>
en HTML en utilisant `texi2html`.


:::{sources}
[Making hypertext documents from TeX](faquk:FAQ-hyper)
:::