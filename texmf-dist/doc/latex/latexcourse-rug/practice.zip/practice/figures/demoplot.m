# Adapted from Octave documentation. Generate pdf with
#   octave demoplot.m
# Matlab should also work (not tested)

[xx, yy] = meshgrid (linspace (-8, 8, 25));
r = sqrt (xx.^2 + yy.^2) + eps;  # eps prevents div/0 errors
zz = sin (r) ./ r;
surf (xx,yy,zz);
print -dpdf demoplot.pdf;