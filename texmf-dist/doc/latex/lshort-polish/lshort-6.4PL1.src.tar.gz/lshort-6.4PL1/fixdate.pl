$v = pop @ARGV;
while (<>) {
 s/{{versionplaceholder}}/$v/;
 print;
}
