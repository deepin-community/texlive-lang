#!/bin/bash
# Ten skrypt przekodowuje pliki pomi�dzy iso8859-cp1250
# Mo�na rozpowszechnia� na licencji GNU. 
#
# Ten plik mo�e si� przyda� do przekodowania 'Wprowadzenia'
# z ISO8859-2 na CP1250
USAGE="Przekodowanie plik�w TeXowych pomi�dzy ISO-8859-2 a CP1250
Pliki winny mie� oznaczenie strony kodowej w postaci 
odpowiedniego wpisu: translate-file=il2-pl lub translate-file=cp1250pl

Spos�b wykorzystania: $0 pliki... "

if test $# = 0 ; then echo "$USAGE" ; fi

for i in $*;
do  perl -i.bak -e 'undef $/; $_ = <>;
      if (/translate-file=il2-pl/) { 
        print STDERR "Przekodowanie iso8859 -> cp1250\n";
        # zmienia tylko pierwsze wyst�pienie
        s/translate-file=il2-pl/translate-file=cp1250pl/ ;
        tr/��ʳ�Ӧ������󶼿/��ʳ�ӌ������󜟿/ ;
        s/\n/\r\n/gm; # unix2dos
      }
      elsif (/translate-file=cp1250pl/) { 
        print STDERR "Przekodowanie cp1250 -> iso8859\n";
        # zmienia tylko pierwsze wyst�pienie
        s/translate-file=cp1250pl/translate-file=il2-pl/ ;
        tr/��ʳ�ӌ������󜟿/��ʳ�Ӧ������󶼿/ ;
        s/\r//g; # dos2unix
      }
      else { print STDERR "Nieustalona strona kodowa *** nic nie robi�\n"; }
      print "$_"; ' $i;
done
