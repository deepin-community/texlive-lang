%p = ( January   => 'Janeiro',
       February  => 'Fevereiro',
       March     => 'Mar�o',
       April     => 'Abril',
       May       => 'Maio',
       June      => 'Junho',
       July      => 'Julho',
       August    => 'Agosto',
       September => 'Setembro',
       October   => 'Outubro',
       November  => 'Novembro',
       December  => 'Dezembro' );

chomp ($d = `date +"%d de %B de %Y"`);
foreach $month (keys %p) {
  $d =~ s/$month/$p{$month}/;
}
$v = pop @ARGV;
while (<>) {
 s/^Vers�o.+/Vers�o~$v, $d/;
 print;
}
