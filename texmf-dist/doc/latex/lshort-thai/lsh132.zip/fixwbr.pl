#
# File: fixwbr.pl
# Date: 2001-10-12 fr
# 
# Try to fix '\wbr ' at the end of line since it cause
# elimitated necessary spaces somehow.
#
# $Id: fixwbr.pl,v 1.1.1.1 2001/11/16 12:01:57 chakka Exp $
#
while (<STDIN>) {
  chomp;

  while ($_ =~ m/^(.+)\\wbr $/) {
    $lastline = $_;
    $_ = <STDIN>;
    chomp;

    if (ord(substr($_,0,1)) > 0x80) {
      print "$lastline\n";
    } else {
      print "$1\n";
    }
    
  }
   
  print "$_\n";
}
