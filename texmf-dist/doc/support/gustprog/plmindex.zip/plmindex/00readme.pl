 *  Copyright (C) 1989 by Chen & Harrison International Systems, Inc.
 *  Copyright (C) 1988 by Olivetti Research Center
 *  Copyright (C) 1987 by Regents of the University of California
 *  Copyright for this release (C) 1999 by Wlodzimierz Macewicz 
             Public Domain

Przedstawiam swoj� w�asn� implementacj� programu makeindex, s�u��cego
do tworzenia skorowidza za pomoc� LaTeX'a. Wersja ta jest oparta na
wersji 2.12. Modyfikacje mia�y na celu umo�liwienie �atwego dostosowania
programu do r�nych j�zyk�w (regu� sortowania). W tej chwili program
uwzgl�dnia nast�puj�ce sposoby kodowania:
iso 8859-2
IBM cp852
MS cp1250
mazowia
oraz kodowanie dla j�z. angielskiego.

Przy okazji modyfikacji programu uporz�dkowa�em nieco kod, w szczeg�lno�ci
spraw� alokacji pami�ci.

O dost�pnych opcjach programu mo�na si� dowiedzie� wywo�uj�c go z parametrem
-h lub -? czyli:
plmindex -h

Program mo�na zbudowa� za pomoc� kompilatora C (gnu, watcom lub MSC)
wywo�uj�c:
make -f makefile.xxx
gdzie zamiast xxx nale�y wpisa�:
msc - kompilator MSC (w tym przypadku nmake  -f makefile.msc)
wcc - kompilator Watcom (w tym przypadku wmake  -f makefile.wcc)
gcc - gnu C++ dla Unixa
djg - gnu C++ dla DOS'a (implementacja DJGPP)
emx - gnu C++ dla DOS'a lub OS'a (implementacja E.Mathesa)

Szczeg�owy opis programu (spos�b do��czenia innych regu� sortowania)
jest dost�pny w WA (Wirtualna Akademia) pod adresem:
http://www.ia.pw.edu.pl/~wujek/tex/idx/plmindex.html
spos�b wykorzystania programu oraz niezb�dne informacje
o LaTeXowych mechanizmach u�ywanych do budowy skorowidza mo�na znale��
pod adresem
http://www.ia.pw.edu.pl/~wujek/tex/idx/program.html
natomiast pod adresem
http://www.ia.pw.edu.pl/~wujek/tex/idx/porzadek.html
znajd� Pa�stwo wyczerpuj�cy artyku� o porz�dku leksykograficznym 
w j�zyku polskim.
